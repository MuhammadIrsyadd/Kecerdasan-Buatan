# Program sederhana melakukan perhitungan
a = 10
b = 5

# Penjumlahan
hasil_jumlah = a + b
print("Hasil penjumlahan dari", a, "dan", b, "adalah", hasil_jumlah)

# Pengurangan
hasil_kurang = a - b
print("Hasil pengurangan dari", a, "dan", b, "adalah", hasil_kurang)

# Perkalian
hasil_kali = a * b
print("Hasil perkalian dari", a, "dan", b, "adalah", hasil_kali)

# Pembagian
hasil_bagi = a / b
print("Hasil pembagian dari", a, "dan", b, "adalah", hasil_bagi)
