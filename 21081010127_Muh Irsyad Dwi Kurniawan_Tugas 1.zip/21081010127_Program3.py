# Program Python untuk meminta input dari pengguna dan mencetaknya ke layar

# Meminta input dari pengguna
nama = input("Masukkan nama: ")
npm = input("Masukkan NPM: ")
alamat = input("Masukkan alamat: ")

# Mencetak input ke layar
print("Nama:", nama)
print("NPM:", npm)
print("Alamat:", alamat)
